<?php
namespace app\lib\enum;

class ScopeEnum{
    // 客户身份
    const User = 16;

    // 管理员身份
    const Super = 32;
}