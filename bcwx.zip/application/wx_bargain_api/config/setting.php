<?php
// 微信配置文件
return [
    'salt' => 'F5ioTsYL',//加密盐
    'cache_expire_in' => 7200,//缓存过期时间
    'host' => 'http://192.168.1.253',
    'activity_time' => '2018/8/20 19:0:0',//活动过期时间
    'bargain_time' => '+5 day',//可以砍价5天，从下单时开始计时
];
