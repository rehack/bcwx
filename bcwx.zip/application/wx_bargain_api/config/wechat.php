<?php
// 微信配置文件
return [
    'app_id'=>'wx150347fed55855dd',
    'app_secret'=>'29ecd0afcf060a72a0c63a9ce275f3b4',
    
];
