<?php
namespace app\wx_bargain_api\model;
use think\Model;

class Helpers extends Model{

    
}