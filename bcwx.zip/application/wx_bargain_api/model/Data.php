<?php
namespace app\wx_bargain_api\model;
use think\Model;

class Data extends Model{

    
}